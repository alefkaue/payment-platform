import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Conta } from "./types";

interface AuthState {
  ready: boolean;
  conta: Conta | null;
  admin: boolean;
  entrar: (conta: Conta, admin: boolean) => void;
  sair: () => void;
}

const Ctx = createContext<AuthState | null>(null);
const KEY = "payflow-session";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [conta, setConta] = useState<Conta | null>(null);
  const [admin, setAdmin] = useState(false);

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(KEY);
      if (raw) {
        const s = JSON.parse(raw);
        setConta(s.conta);
        setAdmin(!!s.admin);
      }
    } catch { /* ignore */ }
    setReady(true);
  }, []);

  const entrar = (c: Conta, a: boolean) => {
    setConta(c); setAdmin(a);
    sessionStorage.setItem(KEY, JSON.stringify({ conta: c, admin: a }));
  };
  const sair = () => { setConta(null); setAdmin(false); sessionStorage.removeItem(KEY); };

  return <Ctx.Provider value={{ ready, conta, admin, entrar, sair }}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth outside AuthProvider");
  return c;
}

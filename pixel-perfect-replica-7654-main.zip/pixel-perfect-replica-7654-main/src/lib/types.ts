export type TipoConta = "PF" | "PJ" | "GOV";
export type Vigencia = "2026" | "2027";

export interface Conta {
  id: number;
  nome: string;
  tipo: TipoConta;
  carteira_id: number;
  saldo: number;
}

export interface Transacao {
  id: number;
  origem_carteira_id: number;
  destino_carteira_id: number;
  valor_bruto: number;
  cbs: number;
  ibs: number;
  liquido: number;
  tipo_destino: TipoConta;
  aplicou_split: boolean;
  auth_metodo: "senha" | "selfie";
  criado_em: string;
}

export interface SplitResultado {
  valor_bruto: number;
  cbs: number;
  ibs: number;
  liquido: number;
  imposto_total: number;
  aplicou_split: boolean;
  vigencia: Vigencia;
}

export interface CarteiraInfo {
  carteira_id: number;
  nome: string;
  tipo: TipoConta;
}

export interface LoginPayload { email: string; senha: string }
export interface LoginResposta { token: string; conta: Conta; admin: boolean }
export interface RegistrarPayload {
  tipo: "PF" | "PJ";
  nome: string;
  email: string;
  senha: string;
  documento: string;
  selfie?: File | null;
}
export interface TransferirPayload {
  destino_carteira_id: number;
  valor: number;
  selfie?: File | null;
}
export interface RetencoesGoverno {
  total_cbs: number;
  total_ibs: number;
  total: number;
  transacoes_com_split: number;
}

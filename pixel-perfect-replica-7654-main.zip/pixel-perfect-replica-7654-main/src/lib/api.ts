/**
 * API seam. Every function mirrors a real backend endpoint's signature and shape.
 * Today they resolve against in-memory mocks; swap bodies for fetch() calls later.
 */
import { calcularSplit } from "./split";
import type {
  CarteiraInfo, Conta, LoginPayload, LoginResposta, RegistrarPayload,
  RetencoesGoverno, SplitResultado, TipoConta, Transacao, TransferirPayload,
} from "./types";
import { carteiras, contaUsuario, genId, transacoes, GOV_CARTEIRA } from "@/mocks/data";

export class ApiError extends Error {
  constructor(message: string, public status = 400) { super(message); }
}

const delay = (ms = 450) => new Promise((r) => setTimeout(r, ms));
const r2 = (n: number) => Math.round(n * 100) / 100;

export async function login({ email, senha }: LoginPayload): Promise<LoginResposta> {
  await delay();
  if (!email || !senha) throw new ApiError("Informe e-mail e senha.", 401);
  return { token: "mock-token", conta: { ...contaUsuario }, admin: email.toLowerCase().includes("admin") };
}

export async function registrar(p: RegistrarPayload): Promise<LoginResposta> {
  await delay(700);
  if (p.senha.length < 8) throw new ApiError("A senha precisa ter ao menos 8 caracteres.");
  const id = genId();
  const conta: Conta = { id, nome: p.nome, tipo: p.tipo, carteira_id: 4000 + id, saldo: 0 };
  carteiras.push({ carteira_id: conta.carteira_id, nome: conta.nome, tipo: conta.tipo });
  Object.assign(contaUsuario, conta);
  transacoes.length = 0;
  return { token: "mock-token", conta: { ...conta }, admin: false };
}

export async function minhaConta(): Promise<Conta> {
  await delay(250);
  return { ...contaUsuario };
}

export async function transacoes_(): Promise<Transacao[]> {
  await delay(350);
  return transacoes
    .filter((t) => t.origem_carteira_id === contaUsuario.carteira_id || t.destino_carteira_id === contaUsuario.carteira_id)
    .sort((a, b) => b.criado_em.localeCompare(a.criado_em));
}
export { transacoes_ as transacoes };

export async function consultarCarteira(id: number): Promise<CarteiraInfo> {
  await delay(300);
  const c = carteiras.find((x) => x.carteira_id === id);
  if (!c || c.tipo === "GOV") throw new ApiError("Carteira não encontrada.", 404);
  return { ...c };
}

export async function simularSplit(valor: number, tipo_destino: TipoConta): Promise<SplitResultado> {
  return calcularSplit(valor, tipo_destino);
}

export async function transferir(p: TransferirPayload): Promise<Transacao> {
  await delay(800);
  const destino = await consultarCarteira(p.destino_carteira_id);
  if (destino.carteira_id === contaUsuario.carteira_id) throw new ApiError("Não é possível transferir para a própria carteira.");
  if (!(p.valor > 0)) throw new ApiError("Valor inválido.");
  if (p.valor > contaUsuario.saldo) throw new ApiError("Saldo insuficiente.");
  if (p.valor > 500 && !p.selfie) throw new ApiError("Selfie obrigatória para valores acima de R$ 500.", 403);
  const s = calcularSplit(p.valor, destino.tipo);
  const t: Transacao = {
    id: genId(),
    origem_carteira_id: contaUsuario.carteira_id,
    destino_carteira_id: destino.carteira_id,
    valor_bruto: s.valor_bruto, cbs: s.cbs, ibs: s.ibs, liquido: s.liquido,
    tipo_destino: destino.tipo, aplicou_split: s.aplicou_split,
    auth_metodo: p.selfie ? "selfie" : "senha",
    criado_em: new Date().toISOString(),
  };
  contaUsuario.saldo = r2(contaUsuario.saldo - s.valor_bruto);
  transacoes.push(t);
  return t;
}

export async function transacaoPorId(id: number): Promise<Transacao> {
  await delay(200);
  const t = transacoes.find((x) => x.id === id);
  if (!t) throw new ApiError("Transação não encontrada.", 404);
  return t;
}

export async function retencoesGoverno(): Promise<RetencoesGoverno> {
  await delay(400);
  const comSplit = transacoes.filter((t) => t.aplicou_split);
  const total_cbs = r2(comSplit.reduce((a, t) => a + t.cbs, 0));
  const total_ibs = r2(comSplit.reduce((a, t) => a + t.ibs, 0));
  void GOV_CARTEIRA;
  return { total_cbs, total_ibs, total: r2(total_cbs + total_ibs), transacoes_com_split: comSplit.length };
}

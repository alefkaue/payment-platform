import { useRef, useState, type ReactNode } from "react";
import { Camera, AlertCircle, Inbox } from "lucide-react";
import { fmtBRL, fmtData, fmtId } from "@/lib/format";
import type { Transacao } from "@/lib/types";
import { cn } from "@/lib/utils";

export function Wordmark({ size = "md" }: { size?: "md" | "lg" }) {
  const lg = size === "lg";
  return (
    <span
      aria-label="payflow"
      className={cn("inline-flex items-baseline font-bold tracking-display text-ink", lg ? "text-4xl" : "text-[1.4rem]")}
    >
      payfl
      <span
        aria-hidden
        className={cn("mx-[0.04em] inline-block rounded-full bg-marca", lg ? "h-[0.56em] w-[0.56em]" : "h-[0.56em] w-[0.56em]")}
      />
      w
    </span>
  );
}

export function SplitBar({ liquido, imposto }: { liquido: number; imposto: number }) {
  const total = liquido + imposto || 1;
  const pTax = (imposto / total) * 100;
  return (
    <div className="flex h-4 w-full gap-[2px]" role="img" aria-label={`Líquido ${fmtBRL(liquido)}, imposto ${fmtBRL(imposto)}`}>
      <div className="h-full rounded-full bg-ink transition-all duration-300" style={{ flexBasis: `${100 - pTax}%` }} />
      {imposto > 0 && (
        <div className="h-full min-w-1.5 rounded-full bg-ocre transition-all duration-300" style={{ flexBasis: `${pTax}%` }} />
      )}
    </div>
  );
}

export function ValueRow({ label, value, tax, strong }: { label: string; value: number; tax?: boolean; strong?: boolean }) {
  return (
    <div className={cn("flex items-center justify-between py-2.5 text-[0.95rem]", tax && "text-tax")}>
      <span className={cn(tax ? "text-tax" : "text-muted-foreground", strong && "font-semibold text-ink")}>
        {tax && <span className="mr-2 inline-block h-2 w-2 rounded-full bg-ocre align-middle" />}
        {label}
      </span>
      <span className={cn("tabular font-medium", strong && "text-lg font-semibold text-ink")}>{fmtBRL(value)}</span>
    </div>
  );
}

export function TxItem({ t, minha }: { t: Transacao; minha: number }) {
  const enviada = t.origem_carteira_id === minha;
  const imposto = t.cbs + t.ibs;
  const valor = enviada ? t.valor_bruto : t.liquido;
  return (
    <li className="flex items-start justify-between gap-4 py-4">
      <div className="flex min-w-0 items-start gap-3">
        <div className="mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-full bg-tint text-xs font-semibold text-mut2">
          {t.tipo_destino === "PJ" && enviada ? "PJ" : enviada ? "PF" : "↓"}
        </div>
        <div className="min-w-0">
          <p className="font-medium text-ink">{enviada ? `Para ${fmtId(t.destino_carteira_id)}` : `De ${fmtId(t.origem_carteira_id)}`}</p>
          <p className="text-sm text-mut3">{fmtData(t.criado_em)}</p>
          {t.aplicou_split && (
            <p className="mt-1 text-sm text-tax">Imposto {fmtBRL(imposto)} → Governo</p>
          )}
        </div>
      </div>
      <span className={cn("tabular shrink-0 font-semibold", enviada ? "text-ink" : "text-pos")}>
        {enviada ? "−" : "+"} {fmtBRL(valor)}
      </span>
    </li>
  );
}

export function TxSkeleton({ n = 4 }: { n?: number }) {
  return (
    <ul className="divide-y divide-border" aria-busy>
      {Array.from({ length: n }).map((_, i) => (
        <li key={i} className="flex items-center gap-3 py-4">
          <div className="h-10 w-10 animate-pulse rounded-full bg-tint" />
          <div className="flex-1 space-y-2">
            <div className="h-3.5 w-32 animate-pulse rounded-full bg-tint" />
            <div className="h-3 w-20 animate-pulse rounded-full bg-tint" />
          </div>
          <div className="h-4 w-20 animate-pulse rounded-full bg-tint" />
        </li>
      ))}
    </ul>
  );
}

export function Empty({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center py-12 text-center">
      <div className="mb-3 grid h-12 w-12 place-items-center rounded-full bg-tint text-mut2"><Inbox size={20} /></div>
      <p className="font-medium text-ink">{title}</p>
      {hint && <p className="mt-1 max-w-xs text-sm text-muted-foreground">{hint}</p>}
    </div>
  );
}

export function ErrorBox({ children }: { children: ReactNode }) {
  return (
    <div role="alert" className="flex items-start gap-2 rounded-[14px] bg-err-bg px-4 py-3 text-sm text-err">
      <AlertCircle size={16} className="mt-0.5 shrink-0" /> <span>{children}</span>
    </div>
  );
}

export function Field({ label, id, children, hint }: { label: string; id: string; children: ReactNode; hint?: string }) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="text-sm font-medium text-mut2">{label}</label>
      {children}
      {hint && <p className="text-xs text-mut3">{hint}</p>}
    </div>
  );
}

export function SelfieCapture({ value, onChange, title = "Selfie de cadastro" }: { value: File | null; onChange: (f: File | null) => void; title?: string }) {
  const ref = useRef<HTMLInputElement>(null);
  const [url, setUrl] = useState<string | null>(null);
  return (
    <div className="rounded-[18px] border border-dashed border-line2 bg-background p-4">
      <div className="flex items-center gap-4">
        <button
          type="button"
          onClick={() => ref.current?.click()}
          className="grid h-20 w-20 shrink-0 place-items-center overflow-hidden rounded-full bg-tint text-mut2 transition hover:bg-line2"
          aria-label={value ? "Trocar selfie" : "Capturar selfie"}
        >
          {url ? <img src={url} alt="Selfie capturada" className="h-full w-full object-cover" /> : <Camera size={24} />}
        </button>
        <div className="min-w-0">
          <p className="font-medium text-ink">{title}</p>
          <p className="mt-0.5 text-sm text-muted-foreground">
            Rosto de frente, sem óculos escuros, lugar iluminado, só você na foto.
          </p>
          <button type="button" onClick={() => ref.current?.click()} className="mt-2 text-sm font-semibold text-ink underline underline-offset-4">
            {value ? "Trocar foto" : "Abrir câmera ou enviar foto"}
          </button>
        </div>
      </div>
      <input
        ref={ref} type="file" accept="image/*" capture="user" className="sr-only"
        onChange={(e) => {
          const f = e.target.files?.[0] ?? null;
          onChange(f);
          setUrl(f ? URL.createObjectURL(f) : null);
        }}
      />
    </div>
  );
}

export function PageTitle({ children, sub }: { children: ReactNode; sub?: ReactNode }) {
  return (
    <div className="mb-6">
      <h1 className="text-3xl text-ink md:text-4xl">{children}</h1>
      {sub && <p className="mt-1 text-muted-foreground">{sub}</p>}
    </div>
  );
}

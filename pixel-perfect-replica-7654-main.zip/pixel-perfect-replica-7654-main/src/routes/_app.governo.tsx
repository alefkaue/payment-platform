import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Lock } from "lucide-react";
import { retencoesGoverno } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { fmtBRL } from "@/lib/format";
import { ErrorBox, PageTitle } from "@/components/payflow/ui";

export const Route = createFileRoute("/_app/governo")({
  head: () => ({
    meta: [
      { title: "Governo — PayFlow" },
      { name: "description", content: "Visão de tesouro: CBS e IBS retidos via split." },
      { property: "og:title", content: "Governo — PayFlow" },
      { property: "og:description", content: "Total de CBS e IBS retidos." },
    ],
  }),
  component: Governo,
});

function Governo() {
  const { admin } = useAuth();
  if (!admin) {
    return (
      <div className="enter">
        <PageTitle>Governo</PageTitle>
        <div className="surface flex items-start gap-3 p-6">
          <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-tint text-mut2"><Lock size={18} /></div>
          <div>
            <p className="font-semibold text-ink">Visão restrita a administradores.</p>
            <p className="mt-1 text-sm text-muted-foreground">Entre com uma conta de administrador para ver o tesouro.</p>
          </div>
        </div>
      </div>
    );
  }
  return <GovernoAdmin />;
}

function GovernoAdmin() {
  const q = useQuery({ queryKey: ["governo"], queryFn: retencoesGoverno });
  return (
    <div className="enter">
      <PageTitle sub="Tesouro · retenções via split automático">Governo</PageTitle>
      {q.isError ? <ErrorBox>Não foi possível carregar as retenções.</ErrorBox> : (
        <div className="space-y-4">
          <section className="surface p-6 md:p-8">
            <p className="text-sm text-muted-foreground">Total retido</p>
            <p className="tabular mt-2 text-5xl font-semibold tracking-display text-tax">
              {q.data ? fmtBRL(q.data.total) : <span className="inline-block h-12 w-56 animate-pulse rounded-xl bg-tint" />}
            </p>
            <p className="mt-2 text-sm text-mut2">{q.data ? `${q.data.transacoes_com_split} transações com split` : "…"}</p>
          </section>
          {q.data && (
            <section className="surface divide-y divide-border px-6 py-2">
              {[["CBS retido", q.data.total_cbs], ["IBS retido", q.data.total_ibs], ["Total", q.data.total]].map(([l, v]) => (
                <div key={l as string} className="flex justify-between py-3.5">
                  <span className="text-mut2">{l}</span>
                  <span className="tabular font-semibold text-tax">{fmtBRL(v as number)}</span>
                </div>
              ))}
            </section>
          )}
        </div>
      )}
    </div>
  );
}

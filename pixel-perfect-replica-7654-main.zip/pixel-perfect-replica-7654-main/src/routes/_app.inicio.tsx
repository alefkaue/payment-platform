import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowUpRight, ListOrdered } from "lucide-react";
import { minhaConta, transacoes } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { fmtBRL, fmtId } from "@/lib/format";
import { Empty, ErrorBox, TxItem, TxSkeleton } from "@/components/payflow/ui";

export const Route = createFileRoute("/_app/inicio")({
  head: () => ({
    meta: [
      { title: "Início — PayFlow" },
      { name: "description", content: "Seu saldo e últimas transações." },
      { property: "og:title", content: "Início — PayFlow" },
      { property: "og:description", content: "Seu saldo e últimas transações." },
    ],
  }),
  component: Inicio,
});

function Inicio() {
  const { sair } = useAuth();
  const nav = useNavigate();
  const conta = useQuery({ queryKey: ["conta"], queryFn: minhaConta });
  const txs = useQuery({ queryKey: ["transacoes"], queryFn: transacoes });

  return (
    <div className="enter space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">Olá,</p>
          <h1 className="text-2xl text-ink">{conta.data?.nome ?? "…"}</h1>
        </div>
        <button onClick={() => { sair(); nav({ to: "/login" }); }} className="btn btn-ghost h-10 px-4 text-sm md:hidden">Sair</button>
      </header>

      <section className="rounded-[22px] bg-ink p-6 text-ink-foreground shadow-lift md:p-8" aria-label="Saldo">
        {conta.isError ? (
          <p>Não foi possível carregar o saldo.</p>
        ) : (
          <>
            <p className="text-sm opacity-60">
              {conta.data ? `Conta ${conta.data.tipo} · ${fmtId(conta.data.carteira_id)}` : "Carregando…"}
            </p>
            <p className="tabular mt-3 text-[2.5rem] font-semibold leading-none tracking-display md:text-5xl">
              {conta.data ? fmtBRL(conta.data.saldo) : <span className="inline-block h-10 w-48 animate-pulse rounded-xl bg-ink-foreground/10" />}
            </p>
            <div className="mt-8 grid grid-cols-2 gap-3">
              <Link to="/transferir" className="btn btn-glass"><ArrowUpRight size={18} /> Transferir</Link>
              <Link to="/extrato" className="btn btn-glass"><ListOrdered size={18} /> Extrato</Link>
            </div>
          </>
        )}
      </section>

      <section className="surface px-5 py-2 md:px-6">
        <div className="flex items-center justify-between pt-4">
          <h2 className="text-lg text-ink">Últimas transações</h2>
          <Link to="/extrato" className="text-sm font-medium text-mut2 hover:text-ink">Ver tudo</Link>
        </div>
        {txs.isLoading ? <TxSkeleton n={4} /> : txs.isError ? (
          <div className="py-4"><ErrorBox>Não foi possível carregar as transações.</ErrorBox></div>
        ) : !txs.data?.length ? (
          <Empty title="Nada por aqui ainda" hint="Suas transferências enviadas e recebidas vão aparecer aqui." />
        ) : (
          <ul className="divide-y divide-border">
            {txs.data.slice(0, 5).map((t) => <TxItem key={t.id} t={t} minha={conta.data?.carteira_id ?? 0} />)}
          </ul>
        )}
      </section>
    </div>
  );
}

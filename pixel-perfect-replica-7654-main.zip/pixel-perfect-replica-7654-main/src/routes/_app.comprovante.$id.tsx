import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Check } from "lucide-react";
import { transacaoPorId } from "@/lib/api";
import { fmtBRL, fmtData, fmtId } from "@/lib/format";
import { ErrorBox, SplitBar, ValueRow } from "@/components/payflow/ui";

export const Route = createFileRoute("/_app/comprovante/$id")({
  head: () => ({
    meta: [
      { title: "Comprovante — PayFlow" },
      { name: "description", content: "Comprovante da transferência com detalhamento do split." },
      { property: "og:title", content: "Comprovante — PayFlow" },
      { property: "og:description", content: "Detalhamento de CBS, IBS e líquido." },
    ],
  }),
  component: Comprovante,
});

function Comprovante() {
  const { id } = Route.useParams();
  const q = useQuery({ queryKey: ["tx", id], queryFn: () => transacaoPorId(Number(id)) });

  if (q.isLoading) return <div className="mx-auto mt-10 h-64 max-w-md animate-pulse rounded-[22px] bg-card" />;
  if (q.isError || !q.data) return <div className="space-y-4"><ErrorBox>Comprovante não encontrado.</ErrorBox><Link to="/inicio" className="btn btn-ghost">Voltar ao início</Link></div>;
  const t = q.data;

  return (
    <div className="enter mx-auto max-w-md text-center">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-tint text-ink"><Check size={28} strokeWidth={2.5} /></div>
      <h1 className="mt-5 text-2xl text-ink">Transferência enviada</h1>
      <p className="tabular mt-2 text-5xl font-semibold tracking-display text-ink">{fmtBRL(t.valor_bruto)}</p>
      <p className="mt-2 text-sm text-muted-foreground">Para {fmtId(t.destino_carteira_id)} · {fmtData(t.criado_em)}</p>

      <section className="surface mt-8 p-5 text-left md:p-6">
        <SplitBar liquido={t.liquido} imposto={t.cbs + t.ibs} />
        <div className="mt-3 divide-y divide-border">
          <ValueRow label="Bruto" value={t.valor_bruto} />
          {t.aplicou_split && <ValueRow label="CBS → Governo" value={t.cbs} tax />}
          {t.aplicou_split && <ValueRow label="IBS → Governo" value={t.ibs} tax />}
          <ValueRow label="Líquido recebido" value={t.liquido} strong />
        </div>
        {!t.aplicou_split && <p className="mt-2 text-sm text-mut2">Destino PF — sem retenção de imposto.</p>}
        <p className="mt-4 rounded-[12px] bg-tint px-3 py-2 font-mono text-xs text-mut2">
          {fmtId(t.id)} · autorizado por {t.auth_metodo}
        </p>
      </section>

      <Link to="/inicio" className="btn btn-ink mt-6 w-full">Voltar ao início</Link>
    </div>
  );
}

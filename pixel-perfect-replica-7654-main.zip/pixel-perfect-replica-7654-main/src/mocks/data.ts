import { calcularSplit } from "@/lib/split";
import type { CarteiraInfo, Conta, Transacao } from "@/lib/types";

export const GOV_CARTEIRA = 1;

export const contaUsuario: Conta = {
  id: 42,
  nome: "Marina Alves",
  tipo: "PF",
  carteira_id: 1042,
  saldo: 8420.35,
};

export const carteiras: CarteiraInfo[] = [
  { carteira_id: GOV_CARTEIRA, nome: "Tesouro — Governo", tipo: "GOV" },
  { carteira_id: 1042, nome: "Marina Alves", tipo: "PF" },
  { carteira_id: 2001, nome: "João Pereira", tipo: "PF" },
  { carteira_id: 3001, nome: "Padaria Aurora Ltda", tipo: "PJ" },
  { carteira_id: 3002, nome: "Estúdio Norte ME", tipo: "PJ" },
];

let nextId = 120;
const mk = (
  origem: number,
  destino: number,
  valor: number,
  daysAgo: number,
  auth: "senha" | "selfie" = "senha",
): Transacao => {
  const tipo = carteiras.find((c) => c.carteira_id === destino)?.tipo ?? "PF";
  const s = calcularSplit(valor, tipo);
  return {
    id: ++nextId,
    origem_carteira_id: origem,
    destino_carteira_id: destino,
    valor_bruto: s.valor_bruto,
    cbs: s.cbs,
    ibs: s.ibs,
    liquido: s.liquido,
    tipo_destino: tipo,
    aplicou_split: s.aplicou_split,
    auth_metodo: auth,
    criado_em: new Date(Date.now() - daysAgo * 86400000 - 3600000 * (daysAgo + 2)).toISOString(),
  };
};

export const transacoes: Transacao[] = [
  mk(1042, 3001, 184.9, 0),
  mk(2001, 1042, 350, 1),
  mk(1042, 3002, 1250, 2, "selfie"),
  mk(1042, 2001, 80, 4),
  mk(3001, 1042, 42.5, 6),
  mk(1042, 3001, 619.4, 9, "selfie"),
];

export const genId = () => ++nextId;
